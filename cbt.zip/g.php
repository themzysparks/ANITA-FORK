<?php
function generateUID($length = 13) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $uid = '';
    for ($i = 0; $i < $length; $i++) {
        $uid .= $characters[rand(0, $charactersLength - 1)];
    }
    return $uid;
}

// Example usage
echo generateUID();
?>